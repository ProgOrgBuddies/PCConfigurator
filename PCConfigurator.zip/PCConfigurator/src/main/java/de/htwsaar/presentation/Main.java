package de.htwsaar.presentation;

public class Main {
    public static void main(String[] args) {
        Dialog dialog = new Dialog();
        dialog.start();
    }

}
